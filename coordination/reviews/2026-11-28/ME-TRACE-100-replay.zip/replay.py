"""Forty falsification probes. Run with Python 3.10+ against the supplied example ZIP."""
import argparse
from copy import deepcopy
from dataclasses import replace
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile


def run(archive):
    tmp = tempfile.TemporaryDirectory()
    root = Path(tmp.name)
    with zipfile.ZipFile(archive) as z:
        z.extractall(root)
    sys.path.insert(0, str(root))
    import booking_capacity as bc
    import choice_history as ch
    import dispatch as dp
    import simulator as sim
    from event_bounds import event_bounds
    rows = []

    def add(i, title, attack, expect, observed, loc, kind="Shipped code"):
        rows.append(dict(id=i, title=title, test=attack, expected=expect,
                         observed=observed, source=loc, method=kind,
                         result="Held" if observed == expect else "Finding"))

    guide = json.loads((root/"guide-booking.json").read_text())
    lab = json.loads((root/"scenario.example.json").read_text())
    worlds = lab["worlds"]
    def check(plan, event, t):
        return event_bounds(dict(plan, check={"event":event,"at":t}))["check"]
    clock = "T:916-937"
    add(1,"Move the receipt across the desk", "Put 17:14 on the coordinator's receipt, then on the duty desk's. The event changes with the holder.",
        [False,True], [check(guide,e,14)["within_bound"] for e in ("answer","desk")], clock)
    by = deepcopy(guide)
    by["deadlines"][0][2]="by"
    add(2,"Change the terms at equality", "Allow booking at 17:20 on the same route. Check coordinator receipts at 17:14 and 17:15.",
        [True,False], [check(by,"answer",t)["within_bound"] for t in (14,15)],clock)
    fork={"clock":"minutes","events":["start","A","B","finish"],"links":[["start","A",3],["start","B",7],["A","finish",8],["B","finish",5]],"deadlines":[["finish",20,"by"]]}
    answer=check(fork,"start",9)
    add(3,"Follow the binding branch","A path of 11 minutes and a competing path of 12 end at minute 20. Test a start at 9 and request the actual limiting path.",
        [False,[1,3],0],[answer["within_bound"],answer["link_indices"],answer["deadline_index"]],clock)
    orphan=deepcopy(guide);orphan["events"].append("unrelated")
    add(4,"Check an unrelated clock","Attach an observation with no path to any declared deadline. A missing bound cannot certify timeliness.",
        None,check(orphan,"unrelated",99)["within_bound"],clock)
    join={"clock":"minutes","events":["request","other","effect"],"links":[["request","effect",3],["other","effect",1]],"deadlines":[["effect",10,"by"]]}
    add(5,"One prerequisite arrives late","Request at 7 fits its individual deadline; a different required signer arrives at 10. Test both before accepting a whole-plan guarantee.",
        [True,False],[check(join,e,t)["within_bound"] for e,t in (("request",7),("other",10))],clock)
    cycle=deepcopy(guide);cycle["links"].append(["kit","answer",0])
    try: event_bounds(cycle); refused=False
    except ValueError: refused=True
    add(6,"Stop a circular timetable","Make the kit required before the original reply. The acyclic calculator must decline this model.",
        True,refused,clock)
    offsets=[[t+3+d<20 for d in range(3)] for t in (14,15,16,17)]
    add(7,"Move the clocks apart","Enumerate the shop's zero-to-two-minute offset for four departure times rather than treating desk and shop time as interchangeable.",
        [[True,True,True],[True,True,False],[True,False,False],[False,False,False]],offsets,"T:425-440","Independent finite model")
    possible={(e//60,h//60,e<h) for e,h in [(22,26),(27,26)]}
    add(8,"Coarse stamps hide order","Two events carry the same displayed minute. Construct two actual second-level sequences with different strict outcomes.",
        [False,True], sorted(flag for a,b,flag in possible if a==b),"M:187-199","Independent finite model")

    cap="T:941-961"
    def alloc(slots, routes):
        return bc.check_capacity(slots,[{"person":n,"confirmed":c,"unconfirmed":u} for n,c,u in routes])
    result=alloc(["1","2"],[("A",["1","2"],[]),("B",["1"],[])])
    add(9,"Move the flexible booking","The first person can use either slot; the second can use only the first. A greedy assignment would strand B.",
        {"A":"2","B":"1"},result.get("allocation"),cap)
    result=alloc(["phone","desk","post"],[("A",["phone"],[]),("B",["phone"],[]),("C",["desk","post"],[])])
    add(10,"Count people inside the bottleneck","Three slots for three people, but A and B share a single compatible slot. Check the named shortfall.",
        [["A","B"],["phone"]],[sorted(result["shortfall"]["people"]),result["shortfall"]["slots"]],cap)
    result=alloc(["p","w"],[("A",["p"],[]),("B",[],["w"])])
    add(11,"A possible volunteer appears","A confirmed route for A and only an open route for B. The desk must name which promise still needs confirmation.",
        ["unconfirmed",[{"person":"B","slot":"w"}]],[result["status"],result["routes_to_confirm"]],cap)
    booked=alloc(["p1","p2","w"],[("A",["p2"],[]),("B",["p2"],[]),("C",["p1"],[])])
    released=alloc(["p1","p2","w"],[("A",["p1","p2"],[]),("B",["p1","p2"],[]),("C",["w"],[])])
    add(12,"Preserve a person's existing promise","C holds p1. Reallocate only in the second world, where C consents to written confirmation before the slot is spent.",
        ["insufficient","confirmed"],[booked["status"],released["status"]],"T:650-658")
    low=sim.simulate_scenario(dict(lab,capacity=1))["result"]
    add(13,"Read every returned policy before recommending it","Set capacity to 1 in the shipped case; fallback requires 2 everywhere. Its label must disappear from every purportedly usable policy, even when it ties on zero on a branch.",
        {"success":"1/2","policies":[["direct","direct"]]},{"success":low["success"],"policies":low["policies"]},"T:1124-1134; ZIP:simulator.support")
    tie=[{"direct":True,"f1":True,"f2":True,"prob":"1"}]
    add(14,"Keep real alternatives at a tie","Both routes are feasible and both always succeed. A tie cannot appoint a single rightful choice.",
        [["direct"],["fallback"]],sim.support(tie,"late",2)["policies"],"T:201-205; ZIP:simulator.support")
    hist=[{"usable":["a","b"],"chosen":"a"},{"usable":["b","c"],"chosen":"b"}]
    nxt=["a","c","d"]; choice="T:795-843"
    got=ch.possible_choices(hist,nxt,explain="c")
    add(15,"Retain an absent intermediary","Remove b from today's menu. Both historical links remain relevant to c's exclusion under the fixed-order model.",
        [["a","d"],[0,1]],[got["possible_next_choices"],[x["history_index"] for x in got["witness"]["steps"]]],choice)
    got=ch.possible_choices([{"usable":["a","b"],"chosen":"a"},{"usable":["b","a"],"chosen":"b"}],["z"],explain="z")
    add(16,"Do not hide a cycle outside today's menu","An unrelated offer z is available; the fixed-ranking observations still contradict each other.",
        "inconsistent",got["status"],choice)
    got=ch.compare_availability(hist,nxt,{"history_index":1,"option":"c"})
    add(17,"Correct one recorded menu","Remove a rival from the second occasion only. The earlier observed choice still stands and c reopens.",
        [["a","d"],["a","c","d"]],[got[k]["possible_next_choices"] for k in ("if_usable","if_unusable")],"T:845-858")
    got=ch.compare_availability(hist,nxt,{"history_index":1,"options":["c"]})
    add(18,"Keep possible and robust choices separate","Across the compatible completions, c can win in some and d can win in all without being anybody's confirmed choice.",
        [["a","c","d"],["a","d"]],[got["possible_in_some_completions"],got["possible_in_every_compatible_completion"]],"T:860-887")
    flip=[{"usable":["a","b"],"chosen":"a"},{"usable":["a","b"],"chosen":"b"}]
    got=ch.choices_across_change(flip,["a","b","d"],{"earliest":0,"latest":2})
    add(19,"Allow a change of aim","The reversed observations fit one between-occasion change. Recover the admissible boundary while keeping the unchosen fresh option open.",
        [1,1,["b","d"]],[got["compatible_boundaries"]["earliest"],got["compatible_boundaries"]["latest"],got["possible_at_some_boundary"]],"T:890-909")
    got=ch.possible_choices([{"usable":["a"],"chosen":"a"}],["a","b"])
    add(20,"Restore a previously unavailable choice","Observed a when it was the only option. After b returns, neither preference nor a refusal has been established.",
        ["a","b"],got["possible_next_choices"],"T:512-531")
    empty=ch.possible_choices(hist,[])["possible_next_choices"]
    abstain=ch.possible_choices([],["decline"])["possible_next_choices"]
    add(21,"An empty menu has no chooser's answer","Compare there being no usable option with the distinct case of an explicitly available decline action.",
        [[],["decline"]],[empty,abstain],choice)
    def inquire(signal,t=7,allowed=sim.ROUTES):
        return sim.inquiry(worlds,positive_likelihoods=signal,observation_time=t,booking_minutes=2,booking_lock=10,allowed_routes=allowed)
    trivial=inquire((1,1))
    add(22,"A copied listing cannot inform by repetition","Copy the same listing into a second display. Its signal is certain in either state.",
        ["0",["positive"]],[trivial["gain_in_success_probability"],sorted(trivial["answers"])],"T:600-613")
    # Among 12 worlds of each cupboard type, the loan works in 9. A positive report
    # occurs in 8 or 4. x,y are the positive-and-loan counts in those two strata.
    optima=[]
    for x in range(5,9):
        for y in range(1,5):
            pos=x+y
            optima.append(F(max(8,pos)+max(4,18-pos),24))
    actual=inquire(("1/3","2/3"))
    add(23,"Remove conditional independence","Use the same 24-world margins but vary the report/loan coupling. Compare the stipulated simulator with the full range of feasible policies.",
        ["3/4","3/4","5/6"],[actual["success_by_acting_on_available_evidence"],str(min(optima)),str(max(optima))],"T:604-613","Shipped code + independent enumeration")
    add(24,"An informative report has no value after the lock","Move a perfect check by one minute. Assume the baseline booking was available before the lock, as the scene stipulates.",
        ["7/8","3/4"],[inquire((0,1),t)["success_by_acting_on_available_evidence"] for t in (7,8)],"T:604-613")
    raw=json.dumps(lab)
    def duplicate(first,second):
        obj=raw.replace('"capacity": 2',f'"capacity": {first}, "capacity": {second}')
        path=root/"ambiguous-input.json";path.write_text(obj)
        proc=subprocess.run([sys.executable,str(root/"simulator.py"),"--input",str(path)],capture_output=True,text=True)
        return "rejected" if proc.returncode else json.loads(proc.stdout)["result"]["success"]
    add(25,"Contradictory capacity entries","Give the same JSON object capacity values 1 and 2. Reverse their order. A material contradiction needs resolution before forecasting.",
        ["rejected","rejected"],[duplicate(1,2),duplicate(2,1)],"T:17-21,201-205; ZIP:simulator --input")
    got=inquire((0,1),allowed=("direct",))
    add(26,"Knowledge cannot supply booking authority","Give a perfect and early report to an operator permitted to book only the cupboard.",
        ["1/2","0"],[got["success_by_acting_on_available_evidence"],got["gain_in_success_probability"]],"T:608-613")
    timeline=dp.DispatchTimeline(hold_effective_at=17,dispatch_confirmed_at=19)
    add(27,"A real effect can still be unknown to the steward","At 18 the effect has happened but confirmation arrives at 19. Preserve the knowledge change and the separate South round.",
        ["UNKNOWN","CONFIRMED_BEFORE_RELEASE","continue"],[dp.evaluate(timeline,18)["hold"],dp.evaluate(timeline,19)["hold"],dp.evaluate(timeline,18)["south_hall"]],"T:742-765")
    pending=dp.DispatchTimeline()
    add(28,"The warning line closes before dispatch","A call at minute 22 is usable but minute 23 is too late. Expiry of that fallback still permits a warning to households.",
        [True,False,True],[dp.evaluate(pending,22)["duty_line_available"],dp.evaluate(pending,23)["duty_line_available"],"warn" in dp.evaluate(pending,23)["next_action"]],"T:748-763")
    def delivery(t,h,d,backup=False,cancelled=False,btime=None):
        return sim.delivery_route(acknowledgement_time=1,delivery_time=t,due_time=d,hardening_time=h,
                 backup_available=backup,backup_cancelled_before_delivery=cancelled,backup_time=btime)["status"]
    add(29,"A spare route can expire independently","Primary arrives late. An on-time backup counts only in the world in which the recipient kept it.",
        ["SUPPORTED_IN_MODEL","NOT_SUPPORTED_IN_MODEL"],[delivery(25,20,17,True,c,15) for c in (False,True)],"T:1138-1157; ZIP:delivery_route")
    add(30,"A missing limit cannot erase a known miss","One delivered route at 30, no backup. In case A the strict boundary is 30 and due is missing. In B delivery is after the known due of 29 and hardening is missing. Every completion fails.",
        ["NOT_SUPPORTED_IN_MODEL"]*2,[delivery(30,30,None),delivery(30,None,29)],"T:235-245; ZIP:delivery_route")
    add(31,"An open route must remain open","The known primary fails but an available backup has no recorded delivery time. A timely completion and a late one are both possible.",
        "UNKNOWN",delivery(25,20,17,True,False,None),"T:235-245; ZIP:delivery_route")
    def dates(worlds):
        return [str(sum((w*f(a,b) for w,a,b in worlds),F())) for f in (lambda a,b:a+b,lambda a,b:int(a or b),lambda a,b:int(a and b))]
    single=[(F(1),1,0)];block=[(F(1,2),1,1),(F(1,2),0,0)]
    add(32,"One session and a two-part course require different events","Keep expected sessions fixed at one. Evaluate count, at-least-one and both dates directly on the same histories.",
        [["1","1","0"],["1","1/2","1/2"]],[dates(single),dates(block)],"T:186-195,965-993","Independent finite model")
    hedge=[(F(1,2),1,1),(F(1,2),1,0)]
    add(33,"Test the floor the holder might decline","Give a failed block one guaranteed date only in the world where its holder actually agreed. Compare the grant and the circle across both offers.",
        [["1","1/2","1/2"],["3/2","1","1/2"]],[dates(block),dates(hedge)],"T:186-205","Independent finite model")
    vals=[F(x,12) for x in range(13) if 0<=x<=6 and 12-6-6+x>=0]
    add(34,"Two half-rates do not fix the timely overlap","Six of twelve occasions have a long window and six get an early reply. Vary their overlap while retaining both margins.",
        ["0","1/2"],[str(min(vals)),str(max(vals))],"T:136-149","Independent enumeration")
    def switch(p):return 1>p and 1-p>=p
    add(35,"Do not trade away the private duet","Compare 0, 1/2, 51/100 and 1 for the chance of blue when Mina's copy is private-only. Both participants' switching terms must hold.",
        [True,True,False,False],[switch(p) for p in map(F,("0","1/2","51/100","1"))],"T:996-1009","Independent finite model")
    # Hidden coin chooses the useful action. Both models/strategies are included.
    outcomes=[(1,0),(0,1)]
    best_fixed=max(F(sum(x[a] for x in outcomes),2) for a in range(2))
    oracle=F(sum(max(x) for x in outcomes),2)
    add(36,"Do not let the selector see hidden worlds","Two equiprobable worlds favour opposite actions. Compare the best implementable uninformed plan with a selector given the hidden world for free.",
        ["1/2","1"],[str(best_fixed),str(oracle)],"T:1071-1095","Independent enumeration")
    model_pairs=[(F(1,5),F(3,10)),(F(4,5),F(9,10))]
    paired=[b-a for a,b in model_pairs]
    add(37,"Crossing model bounds fabricates a loss","Match each plan to its counterfactual in the same model. A cross-model subtraction would give a spurious negative.",
        ["1/10","1/10","-1/2"],[str(min(paired)),str(max(paired)),str(model_pairs[0][1]-model_pairs[1][0])],"T:1077-1095","Independent finite model")
    f=lambda a,b:F(1,2)+F(a*b,2)
    add(38,"Try making the route together","One person has access to a recorder and a second can translate. Neither alone raises the stipulated chance, both together do.",
        ["0","0","1/2"],[str(f(a,b)-f(0,0)) for a,b in ((1,0),(0,1),(1,1))],"T:1159-1170","Independent finite model")
    J=lambda a,b: a*b
    dz=J(1,0)-J(0,0); ds=J(1,1)-J(1,0); inter=J(1,1)-J(1,0)-J(0,1)+J(0,0)
    add(39,"Double-count a cooperative change","For J(z,s)=zs compare total, the two sequential contrasts and the separate interaction.",
        [1,1,1,2],[J(1,1)-J(0,0),dz+ds,inter,dz+ds+inter],"T:1138-1157","Independent finite model")
    # Two equally likely groups of four: successes 3 in one and 1 in the other.
    weighted=(F(3,4)+F(1,4))/2
    add(40,"A surviving cohort can look less hopeful","Drop the more promising group from the display. Test the full-cohort tower identity and the selected subgroup separately.",
        ["1/2","1/4"],[str(weighted),str(F(1,4))],"T:1159-1175","Independent finite model")
    assert [r["id"] for r in rows]==list(range(1,41))
    tmp.cleanup()
    return rows

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive",type=Path)
    parser.add_argument("--json",type=Path)
    args=parser.parse_args()
    results=run(args.archive)
    if args.json:
        args.json.write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
    for r in results:
        print(f'{r["id"]:03} {r["result"]:8} {r["title"]}')
    print(f'{len(results)} probes, {sum(r["result"]=="Finding" for r in results)} findings')
