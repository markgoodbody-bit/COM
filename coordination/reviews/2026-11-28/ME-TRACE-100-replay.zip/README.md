# Replay the 100-probe audit

The audit concerns ME 1.2.2 and the original TRACE 0.6.2, followed by the TRACE 0.6.3 repair. Read ME-TRACE-100.md for all 100 challenges. outputs/ledger.json is the complete machine-readable ledger. The 40 executable probes and the 60 documentary/interpretive probes use different evidence.

## Run the numerical cases offline

From this folder, using Python 3.10 or later, run

    python replay.py examples/TRACE-0.6.2-examples.zip --json before.json
    python replay.py examples/TRACE-0.6.3-examples.zip --json after.json

The original shows findings at 013, 025 and 030. The repaired archive returns 40 held. Each archive is the original byte sequence delivered with its reading edition. outputs/executable.json and outputs/rechecked.json are the recorded observations. The tests use fractions where the cases specify exact probabilities.

## Inspect the books and the web evidence

outputs/source-files.json gives the raw sources and SHA-256 fingerprints. outputs/transport.json records PDF attachments, internal destinations, tagged equations, and the commands run from the downloadable examples. outputs/web-formulas.json contains all 16 display witnesses and the original and repaired preview URLs. The small feedback/tag-state record is a dated observation. coat.md gives all three handovers from probe 098.

To verify the document checks locally, install PyMuPDF and lxml, and provide pdftotext from Poppler. Run the following from the extracted folder with network access.

    python fetch_sources.py
    python verify_public.py
    python inspect_editions.py

The web checks query GitHub’s normal complete preview, which may change after this audit. They save the two public markup captures to checks/. The final release links in the report use an immutable commit. The comparison of the substantive meaning of the 60 reading/edition cases still requires a reader; repeating code cannot supply this judgement.
