# The coat and the buttonhole

Invented on 28 November for probe 098. The same writer applied each route to the same stated facts. This is a decision comparison within the audit. No participant or independent reader took part.

## What is given

Nia wants to wear her late partner’s coat for a private reading on Saturday. She allows a private fitting and has declined photographs. The theatre wardrobe’s Friday fitting was moved without telling her. She paid £6 for the unnecessary journey. Theatre policy covers her fare whether or not she takes another fitting. The duty manager holds that budget. The tailor can hold Saturday’s only twenty-minute slot until Friday 17:00, with confirmations accepted strictly before that time. Allow five minutes between a reply reaching the coordinator and the booking becoming effective. Nia has agreed to be contacted privately, can use the slot and has yet to accept. Lou wants to learn to make a buttonhole. The tailor has independently offered a Wednesday session on scrap they own. Lou hasn’t yet agreed. Lou has no permission to practise on the coat. No photo or public event is necessary for either arrangement.

## Three handovers

**Ordinary prose.** Ask the duty manager to repay Nia’s £6 now. Contact Nia privately about Saturday and get her answer before 16:55 if she wants the fitting. It takes five more minutes to confirm it. Repay the fare either way. Keep the coat and the fitting private. Ask Lou whether they want Wednesday with the tailor on scrap.

**Mechanical Ethics 1.2.2.** Nia has already spent £6. The duty manager can repay her; the choice about the new fitting is still Nia’s. Tell her privately when an answer can still reach the tailor and ask her to decide before 16:55. Maintain the decision against photographs. Lou can learn with the tailor on Wednesday using their scrap. Ask Lou separately. [Chapters 6, 10 and 11](https://github.com/markgoodbody-bit/mechanical-ethics/blob/462b5f342ec3e12c023861aa52720248c82ae8e5/working-editions/v1.2.2/ME-1.2.2.md#6-the-clock-and-the-hand-on-the-door)

**TRACE 0.6.2.** The manager holds the fare remedy, the tailor holds the slot, Nia holds the choice and the image permission, and Lou holds the training decision. The coordinator needs Nia’s reply strictly before 16:55 for confirmation to reach the tailor before 17:00. Return the private offer to Nia and fund the fare now. Offer Lou the agreed Wednesday practice on the separate material. Both acceptances remain open. [First decision and separate offers](https://github.com/markgoodbody-bit/TRACE/blob/a603bb2d6eb0b4bc70698bc684b1d27affb7327d/editions/0.6.2/TRACE-0.6.2.md#book-start-with-the-next-decision)

## What would change the advice

At a 16:55 receipt the fitting misses the lock. Nia still keeps her privacy and fare remedy. If the tailor withdraws Wednesday, Lou’s lesson loses its support. The wardrobe can ask a second tailor to make an offer; Lou’s permission to use scrap would still give no permission to use Nia’s coat. If two people now want the only Saturday place, the desk cannot promise it to both. It needs an accountable allocation decision or another confirmed slot.

All three handovers reached the same consequential decisions under these assumptions. TRACE foregrounded the transfer between the coordinator’s and tailor’s clocks. ME foregrounded the cost already borne and the separate value of learning. The ordinary account could carry both. Because the handovers share a writer who knew the books, this comparison cannot measure how a new reader would perform or which text helped first.
