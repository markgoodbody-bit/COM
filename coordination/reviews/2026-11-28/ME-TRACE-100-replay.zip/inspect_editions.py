from pathlib import Path
import io,sys,shlex,re,json,subprocess,tempfile
from hashlib import sha256
from zipfile import ZipFile
import fitz
from lxml import html

job=Path(__file__).parent.resolve()
inputs=job/'inputs'
outputs=job/'outputs'
def must(answer, msg):
    if not answer:raise AssertionError(msg)
def body(path):return path.read_text()
def digest(value):return sha256(value).hexdigest()
def blocks(source):
    return re.findall(r"^(\x60{3,}|~{3,})([^\n]*)\n(.*?)^\1[ \t]*$",source,re.M|re.S)
def headings(source):return re.findall(r"^# \d+\. (.+)$",source,re.M)
def formulas(doc):
    out=[]
    for ix in range(1,doc.xref_length()):
        if doc.xref_get_key(ix,"S")[1] not in ("/Figure","/Formula","/Span"):continue
        for key in ('Alt','ActualText'):
            s,v=doc.xref_get_key(ix,key)
            if s=="string":out.append(v)
    return out

def web_evidence(path):
    page=html.fromstring(path.read_bytes())
    equations=page.xpath('//math-renderer')
    # Math results include the original expression as a code child or an input attribute.
    typed=[' '.join([el.text_content(),*(el.attrib.values())]) for el in equations]
    paras=[(p.text_content(),len(p.xpath('.//math-renderer'))) for p in page.xpath('//p')]
    plain=[t for t,n in paras if n==0 and 'J_{i,m}' in t]
    return dict(renderers=len(equations),foundation_raw=bool(plain),excerpt=(plain[0][:210] if plain else ''),
                foundation_typed=any('J_{i,m}' in t for t in typed),
                source_prospect=next((t[:440] for t in typed if 'J_{i,m}' in t),''),
                html_sha256=digest(path.read_bytes()))

def verify(version, folder, legacy, comparison, web=None):
    stem='TRACE-'+version
    p=folder/(stem+'.pdf')
    source=body(folder/(stem+'.md'))
    short=body(folder/'spine.md')
    d=fitz.open(p)
    md=fitz.open(inputs/'ME-1.2.2.pdf')
    rows={}
    rows['identity']={str(x.name):digest(x.read_bytes()) for x in [inputs/'ME-1.2.2.pdf',p]}
    for doc,n,wd in [(md,'ME-1.2.2.md',inputs),(d,stem+'.md',folder),(d,stem+'-examples.zip',folder)]:
        must(doc.embfile_get(n)==(wd/n).read_bytes(),n)
    rows['pages']=[len(md),len(d)]
    me=body(inputs/'ME-1.2.2.md')
    hs=headings(me)
    alt=re.findall(r'!\[([^\]]*)\]',me)
    must(hs==headings(body(comparison)) and len(hs)==14,"ME chapters")
    must(len(alt)==4 and all(a.replace("'", "’") in formulas(md) for a in alt),"ME tagged illustrations")
    for doc in (md,d):
        for pg in doc:
            for link in pg.get_links():
                if link['kind'] in (1,4):must(0<=link['page']<len(doc),'internal link')
    rows['me_chapters_figures']=[len(hs),len(alt)]
    refs=d.embfile_get('TRACE-0.5.0.md')
    must(refs==legacy.read_bytes(),'reference')
    originals=[(l,t) for f,l,t in blocks(body(legacy))]
    section=source.split('# TRACE v0.5 — Research specification',1)[1]
    copy=[("json" if l=="application/json" else l,t) for f,l,t in blocks(section)]
    must(originals==copy,('fenced examples',len(originals),len(copy)))
    jsons=[json.loads(t) for l,t in originals if l=='json']
    rows['historical']={'sha256':digest(refs),'code_blocks':len(copy),'json_records':len(jsons)}
    tagged=formulas(d)
    math={"paired":r'D_\{i,m\}.*J_\{i,m\}.*J_\{i,m\}',"threshold":r'1-p.*?(?:geq|≥).*?p',"compression":r'gamma.*?subseteq'}
    for k,rx in math.items():must(any(re.search(rx,v,re.S) for v in tagged),k)
    pages=[i+1 for i,p in enumerate(d) if "Mina and the editor agree to switch" in p.get_text()]
    must(len(pages)==1,'Mina page')
    n=pages[0];strings=[d[n-1].get_text(),subprocess.check_output(['pdftotext','-raw','-f',str(n),'-l',str(n),str(p),'-'],text=True)]
    for t in strings:must('0≤p≤1/2' in ''.join(t.split()),'copying the switch')
    rows['pdf_formula']={'page':n,'extractors':['PyMuPDF','Poppler'],'tagged':list(math)}
    pieces=re.findall(r'TRACE-'+re.escape(version)+r'\.md#([^\s)]+)',short)
    ids=set(re.findall(r'<a id="([^"]+)"',source))
    must(pieces and not set(pieces)-ids,'spine')
    rows['spine_links']=[len(pieces),len(set(pieces))]
    known=[['correction_replay.py'],['-m','unittest','discover','-s','.','-p','test_*.py','-v'],['simulator.py'],['simulator.py','--input','scenario.example.json'],['simulator.py','--deadlines','guide-booking.json'],['simulator.py','--inquiry'],['dispatch.py'],['choice_history.py'],['navigator_reasons.py']]
    shell=next(t for _,l,t in blocks(source) if l=='sh' and 'correction_replay.py' in t)
    cmds=[shlex.split(s) for s in shell.splitlines() if s.strip()]
    must(cmds==[['python3',*args] for args in known], 'commands and order')
    with tempfile.TemporaryDirectory() as tmp:
        z=ZipFile(io.BytesIO(d.embfile_get(stem+'-examples.zip')))
        must(z.testzip() is None and all(not Path(p).is_absolute() and '..' not in Path(p).parts for p in z.namelist()),'archive')
        z.extractall(tmp)
        for c in known:
            v=subprocess.run([sys.executable,*c],cwd=tmp,capture_output=True,text=True,check=True,timeout=45)
            if c[0]=='-m':
                testcount=int(re.search(r'Ran (\d+) tests?',v.stderr).group(1));must(v.stderr.strip().endswith('OK'),'unit suite')
    rows['commands']={'total':len(known),'tests':testcount}
    if web:rows['web']=web_evidence(web)
    return rows
if __name__=='__main__':
    original=verify('0.6.2',inputs,inputs/'TRACE-0.5.0.md',inputs/'ME-1.2.1.md',job/'checks/github-markup.html')
    revised=verify('0.6.3',job/'TRACE/editions/0.6.3',inputs/'TRACE-0.5.0.md',inputs/'ME-1.2.1.md',
                   (job/'checks/github-new.html') if (job/'checks/github-new.html').is_file() else None)
    must(original['web']['foundation_raw'] and not original['web']['foundation_typed'],'original web finding')
    if 'web' in revised:must(not revised['web']['foundation_raw'] and revised['web']['foundation_typed'],'live web repair')
    (outputs/'transport.json').write_text(json.dumps({'0.6.2':original,'0.6.3':revised},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'0.6.2':original,'0.6.3':revised},ensure_ascii=False,indent=2))
