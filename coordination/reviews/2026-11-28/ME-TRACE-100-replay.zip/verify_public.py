from pathlib import Path
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from lxml import html
import json, re
job=Path(__file__).resolve().parent
final='2c3466c588071cc17e5e4ce95c1ffa8900fd7cd6'
repo='https://github.com/markgoodbody-bit/TRACE/blob/'
raw='https://raw.githubusercontent.com/markgoodbody-bit/TRACE/'
old='a603bb2d6eb0b4bc70698bc684b1d27affb7327d'
def read(url):
    with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'}),timeout=30) as response:return response.read()
def fetch_web(ref,version):
    url=repo+ref+'/editions/'+version+'/TRACE-'+version+'.md'
    page=html.fromstring(read(url))
    for script in page.xpath('//script[@type="application/json"]'):
        v=json.loads(script.text or '{}').get('payload',{}).get('codeViewBlobRoute',{})
        if 'richText' in v and v.get('richText') and not v['richTextTruncated']:return v['richText']
    raise ValueError('Complete preview unavailable at '+url)
def run():
    records=[]
    paths=['TRACE-0.6.3.md','spine.md','TRACE-0.6.3.pdf','TRACE-0.6.3-examples.zip']
    def verify(item):
        ref,n=item
        url=raw+ref+'/editions/0.6.3/'+n; data=read(url)
        expected=(job/'TRACE/editions/0.6.3'/n).read_bytes()
        if data!=expected and ref.startswith('reading/'):
            url+='?revision='+final;data=read(url)
        assert data==expected,url
        return [ref,n,len(data),sha256(data).hexdigest(),url]
    with ThreadPoolExecutor(4) as pool:records=list(pool.map(verify,[(ref,p) for ref in (final,'reading/0.6.3') for p in paths]))
    (job/'outputs/public-receipts.json').write_text(json.dumps(records,indent=2)+'\n')
    a=(job/'inputs/TRACE-0.6.2.md').read_text()
    f=a[a.index('# Mathematical foundations\n'):a.index('# Reading the earlier TRACE editions\n')]
    old_spec=(job/'inputs/TRACE-0.5.0.md').read_text()
    def eq(x):return ''.join(x.split())
    get=lambda s:[eq(t) for t in re.findall(r'^\\\[\n(.*?)\n\\\][ \t]*$',s,re.M|re.S)]
    old_eq=get(f)+get(old_spec);assert len(old_eq)==16
    result={}
    for label,ref,v in [('before',old,'0.6.2'),('after',final,'0.6.3'),('reader_link','reading/0.6.3','0.6.3')]:
        h=fetch_web(ref,v)
        if label!='reader_link':(job/'checks'/('github-markup.html' if label=='before' else 'github-new.html')).write_text(h)
        parsed=html.fromstring(h)
        texts={eq(t.text_content()).strip('$') for t in parsed.xpath('//math-renderer')}
        coverage=[x in texts for x in old_eq]
        sample_rows=[{'formula':e,'in_math_renderer':c} for e,c in zip(old_eq,coverage)]
        result[label]={'url':repo+ref+'/editions/'+v+'/TRACE-'+v+'.md','complete_preview':True,'formulas_in_renderers':sum(coverage),'examined':16,'formulas':sample_rows}
        assert sum(coverage)==(0 if label=='before' else 16),[(i+1,b) for i,b in enumerate(coverage)]
    (job/'outputs/web-formulas.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('8 raw public files matched; normal reader links:',{k:v['formulas_in_renderers'] for k,v in result.items()})
if __name__=='__main__':run()
