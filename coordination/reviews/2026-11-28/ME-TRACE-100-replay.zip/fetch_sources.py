from hashlib import sha256
from pathlib import Path
from urllib.request import Request, urlopen
import json

root = Path(__file__).resolve().parent
for name, record in json.loads((root/'outputs/source-files.json').read_text()).items():
    dest = root/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = urlopen(Request(record['url'], headers={'User-Agent':'Mozilla/5.0'}), timeout=40).read()
    if sha256(data).hexdigest() != record['sha256']:
        raise ValueError('Source fingerprint changed: ' + name)
    dest.write_bytes(data)
(root/'checks').mkdir(exist_ok=True)
