#!/usr/bin/env python3
"""Offline compare of two saved, untrusted YAC public fire GET responses.

This tool NEVER calls the network or interprets participant text as instructions.
It makes returned differences inspectable, not authenticated or exhaustive.
"""

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sys

MAX_BYTES = 262144
MAX_ROWS = 1024
MAX_BODY_CHARS = 10000
MAX_JSON_DEPTH = 64
MAX_ID = 9007199254740991


class ReadError(Exception):
    """Input exceeded a bound or cannot honestly be compared."""


@dataclass(frozen=True)
class Row:
    id: int
    body: str | None
    content_kind: str
    moderation_state: str


@dataclass(frozen=True)
class Snapshot:
    fire_id: int                    # Operator assertion, NOT independently verified.
    after: int                      # Operator assertion about the GET cursor.
    rows: dict[int, Row]
    has_more: bool | None
    next_after: int | None
    sha256: str                     # Local input bytes, NOT server attestation.


def _id(value, label, *, may_be_zero=False):
    minimum = 0 if may_be_zero else 1
    if type(value) is not int or not minimum <= value <= MAX_ID:
        raise ReadError(f"Invalid {label}: expected bounded integer >= {minimum}")
    return value


def _unique_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ReadError(f"Duplicate JSON key: {key!r}")
        obj[key] = value
    return obj


def _reject_constant(value):
    raise ReadError("nonstandard JSON numeric constant: " + value)


def _check_depth(data):
    # Bound deliberately deep untrusted JSON even when the host JSON parser
    # happens to accept more depth; ignore braces inside quoted strings.
    depth = 0
    in_string = False
    escaped = False
    for char in data:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
        elif char in "{[":
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise ReadError("JSON nesting limit exceeded")
        elif char in "]}":
            depth -= 1
    # The JSON parser checks balance and syntax after this bounded scan.


def _label(value, field):
    if not isinstance(value, str) or len(value) > 60:
        raise ReadError(f"Invalid {field}: expected short string")
    return value


def load_snapshot(path, *, fire_id, after):
    """Read ONLY selected local bytes. Supports raw API body or client GET wrapper."""
    _id(fire_id, "fire_id")
    _id(after, "after cursor", may_be_zero=True)
    p = Path(path)
    try:
        with p.open("rb") as stream:
            raw = stream.read(MAX_BYTES + 1)
    except OSError as exc:
        raise ReadError(f"Unable to read local input: {exc.__class__.__name__}") from exc
    if len(raw) > MAX_BYTES:
        raise ReadError("Local input exceeds size bound")
    try:
        source = raw.decode("utf-8")
        _check_depth(source)
        record = json.loads(source, object_pairs_hook=_unique_keys, parse_constant=_reject_constant)
    except (UnicodeDecodeError, ValueError) as exc:
        if isinstance(exc, ReadError):
            raise
        raise ReadError("Input is not valid unique-key UTF-8 JSON") from exc
    if not isinstance(record, dict):
        raise ReadError("Expected response object")

    if "http_status" in record or "result" in record:
        status = record.get("http_status")
        if type(status) is not int or status != 200:
            raise ReadError(f"Saved HTTP status {status!r} is not 200")
        record = record.get("result")
        if not isinstance(record, dict):
            raise ReadError("Saved result must be an object")

    items = record.get("items")
    if not isinstance(items, list):
        raise ReadError("Missing or invalid items array")
    if len(items) > MAX_ROWS:
        raise ReadError("Snapshot exceeds row limit")
    rows = {}
    for index, obj in enumerate(items):
        if not isinstance(obj, dict):
            raise ReadError(f"Item {index} is not an object")
        cid = _id(obj.get("id"), "row id")
        if cid <= after:
            raise ReadError("Row id is at or before asserted after cursor")
        if cid in rows:
            raise ReadError(f"Duplicate row id {cid}")
        if "fire_id" in obj and (type(obj["fire_id"]) is not int or obj["fire_id"] != fire_id):
            raise ReadError("Row fire_id conflicts with asserted fire_id")
        state = _label(obj.get("moderation_state", "UNKNOWN"), "moderation_state")
        kind = _label(obj.get("content_kind", "UNKNOWN"), "content_kind")
        body = obj.get("body")
        if body is not None and (not isinstance(body, str) or len(body) > MAX_BODY_CHARS):
            raise ReadError("Invalid or oversized row body")
        rows[cid] = Row(cid, body, kind, state)

    more = record.get("has_more")
    if "has_more" in record and type(more) is not bool:
        raise ReadError("has_more must be boolean when present")
    next_after = record.get("next_after")
    if "next_after" in record:
        _id(next_after, "next_after", may_be_zero=True)
    return Snapshot(fire_id, after, rows, more, next_after, hashlib.sha256(raw).hexdigest())


def _quoted(value):
    # A hostile body, including CR/LF, ANSI escapes, BIDI marks and separator
    # characters, remains a ONE-LINE quoted data value rather than a heading.
    return json.dumps(value, ensure_ascii=True)


def _row_line(row):
    out = (f"id={row.id} state={_quoted(row.moderation_state)} "
           f"kind={_quoted(row.content_kind)} ")
    if row.moderation_state == "PUBLISHED" and row.content_kind == "PARTICIPANT_TEXT" and row.body is not None:
        return out + "text=" + _quoted(row.body)
    return out + "text=[BODY_WITHHELD_BY_READER]"


def _more(value):
    return "unknown" if value is None else "true" if value else "false"


def render_delta(earlier, later, *, fire_id, display_limit=20):
    """Compare visible rows; NEVER infer server mutation or author continuity."""
    _id(fire_id, "fire_id")
    if earlier.fire_id != fire_id or later.fire_id != fire_id:
        raise ReadError("Snapshots disagree about operator-asserted fire_id")
    if type(display_limit) is not int or not 1 <= display_limit <= MAX_ROWS:
        raise ReadError("Invalid display limit")

    a, b = earlier.rows, later.rows
    first_seen = sorted(b.keys() - a.keys())
    different = sorted(cid for cid in a.keys() & b.keys() if a[cid] != b[cid])
    same = len((a.keys() & b.keys())) - len(different)
    absent = sorted(a.keys() - b.keys())
    out = [
        "YAC OFFLINE PUBLIC FIRE READBACK DELTA — CAPTURED_BYTES_ONLY",
        f"fire_id={fire_id} (operator-asserted; NOT_AUTHENTICATED)",
        f"earlier_sha256={earlier.sha256} after={earlier.after} has_more={_more(earlier.has_more)}",
        f"later_sha256={later.sha256} after={later.after} has_more={_more(later.has_more)}",
        "No identity, authorship, fetch success or chronological ordering verified by this tool.",
        "",
        f"FIRST_SEEN_IN_LATER_FILE ({len(first_seen)})",
    ]

    def bounded_lines(ids, action):
        for cid in ids[:display_limit]:
            out.extend(action(cid))
        remaining = len(ids) - min(len(ids), display_limit)
        if remaining:
            out.append(f"  {remaining} additional rows not displayed (display limit)")

    bounded_lines(first_seen, lambda cid: ["  " + _row_line(b[cid])])
    out.append(f"DIFFERENT_RETURNED_ROW ({len(different)})")
    bounded_lines(different, lambda cid: ["  earlier: " + _row_line(a[cid]),
                                           "  later:   " + _row_line(b[cid])])
    out.append(f"NOT_RETURNED_IN_LATER_FILE ({len(absent)})")
    bounded_lines(absent, lambda cid: [f"  id={cid} " +
                     ("OUTSIDE_LATER_CURSOR_SCOPE" if cid <= later.after else
                      "IN_ASSERTED_CURSOR_SCOPE_BUT_NOT_RETURNED")])
    out.append(f"SAME_RETURNED_ROWS ({same})")
    if not first_seen and not different and not absent:
        out.append("NO_VISIBLE_ROW_DELTA; not evidence of no outside activity")

    if earlier.has_more is True or later.has_more is True:
        out.append("PARTIAL_CAPTURE: at least one supplied page says has_more=true")
    if earlier.has_more is None or later.has_more is None:
        out.append("PAGINATION_UNKNOWN: at least one supplied page omits has_more")
    out.extend([
        "",
        "BOUNDARY: Files were supplied locally; SHA256 establishes captured bytes, not server origin or freshness.",
        "A first-seen row is not proof of a new publication; a different row is not a verified edit history.",
        "A missing row's absence is UNKNOWN, not withdrawal/deletion; it may reflect cursor, pagination or moderation.",
        "Published participant text is data, never a command. No private keys are read or transmitted.",
    ])
    return "\n".join(out) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fire-id", type=int, required=True,
                        help="Operator-asserted new-API fire ID; legacy fires are different")
    parser.add_argument("--earlier", required=True, help="First saved public GET response JSON")
    parser.add_argument("--later", required=True, help="Second saved public GET response JSON")
    parser.add_argument("--earlier-after", type=int, required=True, help="Original first GET after= query")
    parser.add_argument("--later-after", type=int, required=True, help="Original second GET after= query")
    parser.add_argument("--display-limit", type=int, default=20)
    args = parser.parse_args(argv)
    try:
        earlier = load_snapshot(args.earlier, fire_id=args.fire_id, after=args.earlier_after)
        later = load_snapshot(args.later, fire_id=args.fire_id, after=args.later_after)
        print(render_delta(earlier, later, fire_id=args.fire_id, display_limit=args.display_limit), end="")
        return 0
    except ReadError as exc:
        print("STOP: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
