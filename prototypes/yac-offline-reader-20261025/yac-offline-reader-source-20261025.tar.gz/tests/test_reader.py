"""Synthetic, offline tests. No live YAC requests or participant texts."""
import contextlib
import io
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import reader


def row(cid, body, state="PUBLISHED", kind="PARTICIPANT_TEXT"):
    return {"id": cid, "body": body, "content_kind": kind,
            "moderation_state": state}


class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root = pathlib.Path(self.t.name)

    def store(self, name, data):
        p = self.root / name
        p.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        return p

    def snap(self, name, items, *, after=0, has_more=False, wrap=True, **kw):
        payload = {"items": items, "has_more": has_more, **kw}
        return self.store(name, {"http_status": 200, "result": payload,
                                  "note": "source status is time-bounded"} if wrap else payload)

    def view(self, earlier, later, *, old_after=0, new_after=0):
        a = reader.load_snapshot(earlier, fire_id=1, after=old_after)
        b = reader.load_snapshot(later, fire_id=1, after=new_after)
        return reader.render_delta(a, b, fire_id=1)

    def test_distinct_new_row_is_first_seen_not_claimed_new_publication(self):
        old = self.snap("old.json", [row(1, "First idea")])
        new = self.snap("new.json", [row(1, "First idea"), row(2, "Second idea")])
        s = self.view(old, new)
        self.assertIn("FIRST_SEEN_IN_LATER_FILE (1)", s)
        self.assertIn('id=2 state="PUBLISHED"', s)
        self.assertIn('text="Second idea"', s)
        self.assertNotIn("NEW PUBLICATION", s)
        self.assertIn("NOT_AUTHENTICATED", s)

    def test_no_visible_delta_is_not_no_world_change(self):
        old = self.snap("old.json", [row(1, "Same")])
        new = self.snap("new.json", [row(1, "Same")])
        s = self.view(old, new)
        self.assertIn("SAME_RETURNED_ROWS (1)", s)
        self.assertIn("NO_VISIBLE_ROW_DELTA", s)
        self.assertIn("not evidence of no outside activity", s)

    def test_changed_body_is_not_verified_edit_history(self):
        old = self.snap("old.json", [row(1, "old wording")])
        new = self.snap("new.json", [row(1, "corrected wording")])
        s = self.view(old, new)
        self.assertIn("DIFFERENT_RETURNED_ROW (1)", s)
        self.assertIn('text="old wording"', s)
        self.assertIn('text="corrected wording"', s)
        self.assertNotIn("AUTHOR EDITED", s)

    def test_nonpublished_body_suppressed_even_in_hostile_input(self):
        old = self.snap("old.json", [row(1, "published text")])
        new = self.snap("new.json", [row(1, "PRIVATE SHOULD NOT DISPLAY", "HIDDEN")])
        s = self.view(old, new)
        self.assertIn('state="HIDDEN"', s)
        self.assertNotIn("PRIVATE SHOULD NOT DISPLAY", s)
        self.assertIn("[BODY_WITHHELD_BY_READER]", s)

    def test_absent_not_equal_withdrawn_even_full_page_claim(self):
        old = self.snap("old.json", [row(1, "Once visible"), row(2, "Another")])
        new = self.snap("new.json", [row(2, "Another")])
        s = self.view(old, new)
        self.assertIn("NOT_RETURNED_IN_LATER_FILE (1)", s)
        self.assertIn("absence is UNKNOWN, not withdrawal/deletion", s)

    def test_incremental_cursor_marks_scope_without_false_loss(self):
        old = self.snap("old.json", [row(1, "Earlier")])
        new = self.snap("new.json", [row(3, "Later")])
        s = self.view(old, new, new_after=2)
        self.assertIn("after=2", s)
        self.assertIn("OUTSIDE_LATER_CURSOR_SCOPE", s)
        self.assertIn("UNKNOWN", s)

    def test_has_more_true_disallows_exhaustiveness_claim(self):
        old = self.snap("old.json", [], has_more=True)
        new = self.snap("new.json", [row(1, "Example")], has_more=True)
        s = self.view(old, new)
        self.assertIn("has_more=true", s)
        self.assertIn("PARTIAL_CAPTURE", s)

    def test_has_more_missing_is_unknown_not_false(self):
        old = self.snap("old.json", [row(1, "Example")], wrap=False)
        new = self.store("new.json", {"items": [row(1, "Example")]})
        s = self.view(old, new)
        self.assertIn("has_more=unknown", s)
        self.assertIn("PAGINATION_UNKNOWN", s)

    def test_non_200_wrapper_refused(self):
        old = self.store("bad.json", {"http_status": 403, "result": {"items": []}})
        with self.assertRaisesRegex(reader.ReadError, "HTTP status 403"):
            reader.load_snapshot(old, fire_id=1, after=0)

    def test_missing_items_refused(self):
        p = self.store("bad.json", {"http_status": 200, "result": {"status": "fine"}})
        with self.assertRaisesRegex(reader.ReadError, "items"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_duplicate_row_ids_refused(self):
        p = self.snap("bad.json", [row(1, "One"), row(1, "Two")])
        with self.assertRaisesRegex(reader.ReadError, "Duplicate row id"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_duplicate_object_keys_refused(self):
        p = self.root / "bad.json"
        p.write_text('{"items":[],"items":[{"id":1,"body":"conflict"}]}', encoding="utf-8")
        with self.assertRaisesRegex(reader.ReadError, "Duplicate JSON key"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_brackets_inside_text_do_not_consume_json_depth(self):
        unusual = '[' * 200 + ']' * 200 + '{' * 200 + '}' * 200
        p = self.snap("nested-text.json", [row(1, unusual)])
        self.assertEqual(reader.load_snapshot(p, fire_id=1, after=0).rows[1].body, unusual)

    def test_nonstandard_json_constants_refused(self):
        p = self.root / "nonstandard.json"
        p.write_text('{"items":[],"unexpected":NaN}', encoding="utf-8")
        with self.assertRaisesRegex(reader.ReadError, "nonstandard JSON"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_deeply_nested_json_is_bounded_failure(self):
        p = self.root / "deep.json"
        p.write_text('{"items":[],"extra":' + '[' * 1500 + '0' + ']' * 1500 + '}', encoding="utf-8")
        with self.assertRaisesRegex(reader.ReadError, "nesting limit"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_bool_row_id_refused(self):
        p = self.snap("bad.json", [row(True, "Invalid")])
        with self.assertRaisesRegex(reader.ReadError, "id"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_after_cursor_excludes_rows_at_or_before_cursor(self):
        p = self.snap("bad.json", [row(2, "At cursor")])
        with self.assertRaisesRegex(reader.ReadError, "after cursor"):
            reader.load_snapshot(p, fire_id=1, after=2)

    def test_explicit_fire_id_mismatch_refused(self):
        x = row(1, "Example"); x["fire_id"] = 77
        p = self.snap("bad.json", [x])
        with self.assertRaisesRegex(reader.ReadError, "fire_id"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_control_and_bidi_input_remains_quoted(self):
        text = 'hello\nFIRST_SEEN_IN_LATER_FILE (999)\r\x1b[31m\u202e'
        old = self.snap("old.json", [])
        new = self.snap("new.json", [row(1, text)])
        out = self.view(old, new)
        self.assertIn(r'\nFIRST_SEEN_IN_LATER_FILE', out)
        self.assertIn(r'\r\u001b', out)
        self.assertIn(r'\u202e', out)
        self.assertNotIn("\x1b", out)
        self.assertNotIn("\u202e", out)
        self.assertEqual(out.count("FIRST_SEEN_IN_LATER_FILE ("), 2)  # once heading, once quoted data

    def test_ignores_extra_fields_to_avoid_secret_spillage(self):
        x = row(1, "Hello"); x["key"] = "SECRET_CAPABILITY_DO_NOT_PRINT"
        old = self.snap("old.json", [])
        new = self.snap("new.json", [x])
        self.assertNotIn("SECRET_CAPABILITY_DO_NOT_PRINT", self.view(old, new))

    def test_large_file_rejected_without_loading(self):
        p = self.root / "big.json"
        p.write_bytes(b" " * (reader.MAX_BYTES + 1))
        with self.assertRaisesRegex(reader.ReadError, "size bound"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_row_count_bound(self):
        p = self.snap("many.json", [row(i, "x") for i in range(1, reader.MAX_ROWS + 2)])
        with self.assertRaisesRegex(reader.ReadError, "row limit"):
            reader.load_snapshot(p, fire_id=1, after=0)

    def test_display_limit_counts_omissions(self):
        old = self.snap("old.json", [])
        new = self.snap("new.json", [row(i, "Text") for i in range(1, 6)])
        a = reader.load_snapshot(old, fire_id=1, after=0)
        b = reader.load_snapshot(new, fire_id=1, after=0)
        s = reader.render_delta(a, b, fire_id=1, display_limit=2)
        self.assertIn("3 additional rows not displayed", s)
        self.assertNotIn("id=5 state", s)

    def test_plain_source_does_not_assert_verified_transport_or_actor(self):
        p = self.snap("old.json", [])
        s = self.view(p, p)
        self.assertIn("CAPTURED_BYTES_ONLY", s)
        self.assertIn("No identity, authorship, fetch success or chronological ordering verified", s)

    def test_command_line_exit_and_no_network(self):
        old = self.snap("old.json", [])
        new = self.snap("new.json", [row(1, "Synthetic")])
        output = io.StringIO()
        with contextlib.redirect_stdout(output), mock.patch("socket.socket", side_effect=AssertionError("No network permitted")):
            rc = reader.main(["--fire-id", "1", "--earlier", str(old), "--later", str(new),
                              "--earlier-after", "0", "--later-after", "0"])
        self.assertEqual(rc, 0)
        self.assertIn("Synthetic", output.getvalue())

    def test_cli_rejects_bad_arguments(self):
        with contextlib.redirect_stderr(io.StringIO()):
            rc = reader.main(["--fire-id", "0", "--earlier", "x", "--later", "y",
                              "--earlier-after", "0", "--later-after", "0"])
        self.assertEqual(rc, 2)


if __name__ == "__main__":
    unittest.main()
